package view;

import java.text.ParseException;

import model.RegisterModel;

public interface IntRegistroView {
	public boolean newRegisterAdded() throws ParseException;
}
