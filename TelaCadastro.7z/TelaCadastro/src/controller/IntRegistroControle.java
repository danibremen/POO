package controller;

import java.text.ParseException;

import model.RegisterModel;
import view.RegistroView;

public interface IntRegistroControle{
	public void notifyView(RegisterModel form);
	public void addUser(RegistroView form) throws ParseException;
}
