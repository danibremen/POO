package main;

import java.awt.Dimension;

import javax.swing.JFrame;

import controller.RegistroControle;
import model.RegisterModel;
import view.RegistroView;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RegistroView registerScreen = new RegistroView();
		registerScreen.setTitle("Cadastro");
		registerScreen.setResizable(false);
		//registerScreen.setPreferredSize(new Dimension(500,300));
		registerScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
