package model;


import java.util.List;

public interface IntServicoBase<Object> {
	public void addUser(Object form);
	public Object getUser(Object form);
	public List<Object> getAllUsers();
	public void DeleteUser(int id);
}
