package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConexao {
	private String usuario = "test";
	private String senha = "test";
	private static DataBaseConexao instance;
	
	public DataBaseConexao() {}
	
	public static DataBaseConexao getInstance() {
		if(instance == null) {
			instance = new DataBaseConexao();
		}
		return instance;
	}
	
	public Connection getConnection() {
		Connection conn;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cadastros?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", 
					usuario, 
					senha);
			
			return conn;
			}catch(SQLException e){
				throw new RuntimeException(e);
		}
	}
}
