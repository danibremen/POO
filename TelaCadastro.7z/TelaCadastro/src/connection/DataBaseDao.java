package connection;
import java.sql.Connection;

public abstract class DataBaseDao {
	public Connection getConnection() {
		return DataBaseConexao.getInstance().getConnection();
	}
}
