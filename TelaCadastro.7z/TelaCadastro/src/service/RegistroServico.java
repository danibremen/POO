package service;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import controller.RegistroControle;
import model.RegistroDAO;
import model.RegisterModel;
import view.RegistroView;

public class RegistroServico implements IServico {
	private RegistroControle registerController;
	
	public RegistroServico() {}
	
	public RegistroServico(RegistroControle registerController, RegisterModel registerModel) {
		this.registerController = new RegistroControle();
	}

	@Override
	public void notifyError() {
		registerController.notifyWarning();
	}

	@Override
	public void addUser(RegistroView form) throws ParseException {
		RegisterModel registerModel = new RegisterModel();
		registerModel.setFirstName(form.getFisrtNameField().getText());
		registerModel.setLastName(form.getLastNamefield().getText());
		registerModel.setCpf(form.getCpfField().getText());
		registerModel.setRg(form.getRgField().getText());
		registerModel.setEmail(form.getEmailField().getText());
		registerModel.setBirthDate(new SimpleDateFormat("dd/MM/yyyy").parse(form.getBirthdayField().getText()));
		registerModel.setUser(form.getUserField().getText());
		registerModel.setPassword(form.getPasswordField().getPassword());
		registerModel.addUser();
	}
	public void invokeDAO(RegisterModel registerModel) {
		RegistroDAO registerDAO = new RegistroDAO();
		registerDAO.addUser(registerModel);
	}
}
