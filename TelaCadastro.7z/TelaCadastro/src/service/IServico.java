package service;

import java.text.ParseException;

import view.RegistroView;

public interface IServico {
	public void addUser(RegistroView form) throws ParseException;
	public void notifyError();
}
